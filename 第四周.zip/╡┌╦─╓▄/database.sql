create database 24zhuzi;
use 24zhuzi;

create table user_login
(user_id varchar(20),
mob char(11) not null unique,
pswd varchar(20) not null,
primary key (user_id))
ENGINE=InnoDB default charset=utf8;

create table user_infor
(user_id varchar(20),
mob char(11) not null unique,
user_name varchar(30),
nickname varchar(20),
id_number char(18),
primary key (user_id),
foreign key (user_id) references user_login,
foreign key (mob) references user_login)
ENGINE=InnoDB default charset=utf8;

create table user_add
(user_id varchar(20),
province varchar(20) not null,
city varchar(20),
county_or_district varchar(20) not null,
detailed_add varchar(100) not null,
primary key (user_id),
foreign key (user_id) references user_login)
ENGINE=InnoDB default charset=utf8;

create table user_account
(user_id varchar(20),
balance int,
points int,
primary key (user_id),
foreign key (user_id) references user_login)
ENGINE=InnoDB default charset=utf8;

create table balance_log
(bal_log_id char(20),
bal_log_time datetime,
user_id varchar(20) not null,
bal_val int,
primary key (bal_log_id),
foreign key (user_id) references user_login)
ENGINE=InnoDB default charset=utf8;

create table points_log
(pts_log_id char(20),
pts_log_time datetime,
user_id varchar(20) not null,
pts_source char(1) not null,
pts_value int,
primary key (pts_log_id),
foreign key (user_id) references user_login)
ENGINE=InnoDB default charset=utf8;

create table seller
(user_id varchar(20),
store_name varchar(30) not null unique,
store_stars char(1) not null,
ttl_turnover int,
primary key (user_id),
foreign key (user_id) references user_login)
ENGINE=InnoDB default charset=utf8;

create table category
(cat_id varchar(20),
cat_name varchar(20) not null unique,
primary key (cat_id))
ENGINE=InnoDB default charset=utf8;

create table brand
(br_id varchar(20),
br_name varchar(20) not null unique,
primary key (br_id))
ENGINE=InnoDB default charset=utf8;

create table spu
(spu_id varchar(20),
spu_name varchar(50) not null,
cat_id varchar(20) not null,
br_id varchar(20) not null,
primary key (spu_id),
foreign key (cat_id) references category,
foreign key (br_id) references brand)
ENGINE=InnoDB default charset=utf8;

create table sku
(sku_id varchar(20),
spu_id varchar(20) not null,
user_id varchar(20) not null,
stock int,
price int,
primary key (sku_id),
foreign key (spu_id) references spu,
foreign key (user_id) references seller)
ENGINE=InnoDB default charset=utf8;

create table spec
(spec_id varchar(20),
spec_name varchar(40) not null unique,
primary key (spec_id))
ENGINE=InnoDB default charset=utf8;

create table spu_spec
(spu_id varchar(20),
spec_id varchar(20) not null,
primary key (spu_id),
foreign key (spu_id) references spu,
foreign key (spec_id) references spec)
ENGINE=InnoDB default charset=utf8;

create table spec_val
(spec_val_id varchar(20),
spec_id varchar(20) not null,
primary key (spec_val_id),
foreign key (spec_id) references spec)
ENGINE=InnoDB default charset=utf8;

create table sku_spec_val
(sku_id varchar(20),
spec_val_id varchar(20),
primary key (sku_id),
foreign key (sku_id) references sku,
foreign key (spec_val_id) references spec_val)
ENGINE=InnoDB default charset=utf8;

create table seller_statistical_report
(sku_id varchar(20),
user_id varchar(20) not null,
sale_vol int,
turnover int,
primary key (sku_id),
foreign key (sku_id) references sku,
foreign key (user_id) references seller)
ENGINE=InnoDB default charset=utf8;

create table cart
(user_id varchar(20),
sku_id varchar(20),
cart_ttl_price int,
cart_qty int,
primary key (user_id,sku_id),
foreign key (user_id) references user_login,
foreign key (sku_id) references sku)
ENGINE=InnoDB default charset=utf8;

create table collection
(user_id varchar(20),
spu_id varchar(20),
store_name varchar(30),
primary key (user_id,spu_id,store_name),
foreign key (user_id) references user_login,
foreign key (spu_id) references spu,
foreign key (store_name) references seller)
ENGINE=InnoDB default charset=utf8;

create table orders
(order_id varchar(20),
user_id varchar(20)not null,
sku_id varchar(20)not null,
order_ttl_price int,
order_qty int,
order_time datetime,
order_cplt char(1) not null,
primary key (order_id),
foreign key (user_id) references user_login,
foreign key (sku_id) references sku)
ENGINE=InnoDB default charset=utf8;